export const LIST_PRODUCT 		= 'LIST_PRODUCT';
export const BUY_PRODUCT 		= 'BUY_PRODUCT';
export const UPDATE_PRODUCT 	= 'UPDATE_PRODUCT';
export const REMOVE_PRODUCT 	= 'REMOVE_PRODUCT';
export const CHANGE_NOTIFY 		= 'CHANGE_NOTIFY';