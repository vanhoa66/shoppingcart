export const NOTI_READY_TO_BUY 		= "Ready to buy product";
export const NOTI_GREATER_THAN_ONE  = "Quantity must equal or greater than 1";
export const NOTI_ACT_ADD  			= "Added successfull !!";
export const NOTI_ACT_UPDATE  		= "Updated successfull !!";
export const NOTI_ACT_DELETE  		= "Deleted successfull !!";
export const NOTI_EMPTY_PRODUCT  	= "Empty Product";

export const CARTS_FROM_LOCAL_STOGARE 	= "cart123213";